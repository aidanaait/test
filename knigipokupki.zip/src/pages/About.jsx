import App from "../App";

const About = () => {
    return ( 
        <h1>About</h1>
     );
}
 
export default About;